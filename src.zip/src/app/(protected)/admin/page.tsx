async function getPending() {
  const res = await fetch("http://localhost:3000/api/admin/approvals", { credentials: "include" });
  return res.json();
}

export default async function AdminApprovalsPage() {
  const data = await getPending();

  return (
    <div>
      <h1 className="text-xl font-semibold">موافقات الأدمن</h1>
      <p className="text-sm text-gray-600 mt-1">اعتماد أو رفض الطلبات الجديدة.</p>

      <div className="mt-4 space-y-3">
        {data.pending.map((r: any) => (
          <div key={r.id} className="border rounded-2xl p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="font-semibold">{r.id}</div>
                <div className="text-sm text-gray-600">
                  {new Date(r.createdAt).toLocaleString("ar-SA")} — عناصر: {r.items.length}
                </div>
              </div>

              <div className="flex gap-2">
                <form action="/api/admin/approvals" method="POST">
                  <input type="hidden" name="id" value={r.id} />
                  <input type="hidden" name="action" value="approve" />
                  <button className="px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">
                    موافقة
                  </button>
                </form>

                <form action="/api/admin/approvals" method="POST" className="flex gap-2">
                  <input type="hidden" name="id" value={r.id} />
                  <input type="hidden" name="action" value="reject" />
                  <input
                    name="reason"
                    placeholder="سبب الرفض"
                    className="border rounded-xl px-3 py-2 text-sm"
                  />
                  <button className="px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700">
                    رفض
                  </button>
                </form>
              </div>
            </div>
          </div>
        ))}

        {data.pending.length === 0 && (
          <div className="border rounded-2xl p-4 text-gray-700">لا يوجد طلبات بانتظار الموافقة.</div>
        )}
      </div>
    </div>
  );
}
