import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export async function POST(
  req: Request,
  { params }: { params: { id: string } }
) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (user.role !== "ADMIN") return NextResponse.json({ error: "forbidden" }, { status: 403 });

  const body = await req.json().catch(() => null);
  const rejectReason = body?.rejectReason?.toString() || "No reason";

  const updated = await prisma.request.update({
    where: { id: params.id },
    data: {
      status: "REJECTED",
      rejectReason,
      approvedById: user.userId,
      approvedAt: new Date(),
    },
  });

  return NextResponse.json({ ok: true, request: updated });
}
