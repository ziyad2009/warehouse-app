
import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

export async function POST(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (user.role !== "ADMIN") return NextResponse.json({ error: "forbidden" }, { status: 403 });

  const updated = await prisma.request.update({
    where: { id: params.id },
    data: {
      status: "APPROVED",
      approvedAt: new Date(),
      approvedById: user.userId,
      rejectReason: null,
    },
  });

  return NextResponse.json({ ok: true, request: updated });
}
 